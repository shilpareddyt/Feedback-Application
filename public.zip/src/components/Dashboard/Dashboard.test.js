import { render} from '@testing-library/react';
import Dashboard from './Dashboard';
import MultiStep from '../MultiStep/MultiStep';
import Question from '../Question/Question';
import Option from '../Options/Option';
jest.mock('../MultiStep/MultiStep')
test('test MultiStep Component is rendered in Dashboard or not', ()=>{
  render(<Dashboard />);
  expect(MultiStep).toHaveBeenCalled()
 
})
jest.mock('../Question/Question')
test('test Question Component is rendered in Dashboard or not', ()=>{
  render(<Dashboard />);
  expect(Question).toHaveBeenCalled()
 
})
jest.mock('../Options/Option')
test('test Option Component is rendered in Dashboard or not', ()=>{
  render(<Dashboard />);
  expect(Option).toHaveBeenCalled()
 
})
