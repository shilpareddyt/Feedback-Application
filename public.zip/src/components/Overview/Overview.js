
function Overview (props){
    const questions=props.questions;
    return (
        <>
        <div className="">
        {questions.map((option)=>{
            return <><h5>{option.title}</h5>
            <h4>{option.answer}</h4></>
                })}
        <button>sumbit</button>
         </div>
        </>
    );
    }
    export default Overview;