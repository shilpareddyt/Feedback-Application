
function Question(props) { 
    return (
            <div className=" text-[40px] font-bold text-white">{props.question.title}
                    </div>
    );
}
export default Question;