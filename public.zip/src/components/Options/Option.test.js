import { render,screen} from '@testing-library/react';
import ThumbUpAltIcon from '@mui/icons-material/ThumbUpAlt';
import ThumbDownIcon from '@mui/icons-material/ThumbDown';
import SentimentNeutralIcon from '@mui/icons-material/SentimentNeutral';

import Option from './Option';

const mockFn = jest.fn(cb => cb(null, true));
const mockOptions= jest.mock[{ id: 1, icon: <ThumbUpAltIcon fontSize='large' />, label: 'Good' },
{ id: 2, icon: <SentimentNeutralIcon fontSize='large' />, label: 'Not Sure' },
{ id: 3, icon: <ThumbDownIcon fontSize='large' />, label: 'Unlike' }
];
test('renders Options icons correctly', ()=>{
  render(<Option options={mockOptions} saveOptionsInListOfQuestions={mockFn}/>);
  const title=screen.findAllByLabelText();
  expect(title).toBeInTheDocument();
})
