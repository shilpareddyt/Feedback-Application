import { createSlice } from '@reduxjs/toolkit'

const initialState = {
    Questions: [
        { id: 1, title: 'How was your week all ?', answer: '' },
        { id: 2, title: 'How did you like last week', answer: '' },
        { id: 3, title: 'How well are you last week', answer: '' },
    ]
}

export const questionSlice = createSlice({
    name: "question",
    initialState,
    reducers: {
        updateQuestions: (state, action) => {
            state.Questions = action.payload
        }
    }
})
export const { updateQuestions } = questionSlice.actions
export default questionSlice.reducer