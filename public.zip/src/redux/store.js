import { configureStore } from '@reduxjs/toolkit'
import TodoReducers from './slice'

const store = configureStore({
    reducer: TodoReducers,
});

export default store;